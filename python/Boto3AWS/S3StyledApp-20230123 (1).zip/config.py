

BUCKET = "FILL_IN_WITH_THE_NAME_OF_YOUR_S3_BUCKET" # this S3 bucket should exist, usually, you should not hardcode this here!

UPLOAD_FOLDER = "uploads" # used as a temporary storage area
